## Packeaged used in FrontEnd

1. axios: used to send api calls
2. react-router-dom: use to create routes
3. react-toastify: use to display toast notifications
